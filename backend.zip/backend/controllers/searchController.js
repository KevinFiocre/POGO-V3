exports.searchHandler = (req, res) => {
    res.json({ message: "API Search fonctionne !" });
};